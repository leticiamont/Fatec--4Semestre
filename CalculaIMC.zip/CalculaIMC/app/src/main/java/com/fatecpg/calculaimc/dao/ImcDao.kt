package com.fatecpg.calculaimc.dao

import com.fatecpg.calculaimc.model.IMC

class ImcDao {
    companion object{
        private var imc: IMC? = null
    }

    fun calculaIMC(imc: IMC){
        Companion.imc = imc
    }

    fun exibirIMC():IMC{
        return Companion.imc?:IMC()
    }
}