package com.fatecpg.calculaimc.model

data class IMC(
    val imc:String = ""
)
