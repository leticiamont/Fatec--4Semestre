package com.fatecpg.calculaimc.view

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.fatecpg.calculaimc.R
import com.fatecpg.calculaimc.dao.ImcDao
import com.fatecpg.calculaimc.model.IMC
import kotlin.math.round

class MainActivity : AppCompatActivity() {
    val dao = ImcDao()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val edtAltura = findViewById<EditText>(R.id.edtAltura)
        val edtPeso = findViewById<EditText>(R.id.edtPeso)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)

        btnCalcular.setOnClickListener {
            val altura = edtAltura.text.toString().toDouble()
            val peso = edtPeso.text.toString().toDouble()
            val calculo = peso / (altura * altura)
            val resul = (calculo*10000)
            val imc = IMC(resul.toString())
            dao.calculaIMC(imc)
            val intent = Intent(this, ResultadoActivity::class.java)
            startActivity(intent)
        }
    }
}