package com.fatecpg.calculaimc.view

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.fatecpg.calculaimc.R
import com.fatecpg.calculaimc.dao.ImcDao
import com.fatecpg.calculaimc.model.IMC

class ResultadoActivity : AppCompatActivity() {
    val dao = ImcDao()
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)
        val txvResultado = findViewById<TextView>(R.id.txvResultado)
        val resultado = dao.exibirIMC();
        txvResultado.text = resultado.imc
    }
}